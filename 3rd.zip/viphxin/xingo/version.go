package xingo

const version = "0.0.1"
