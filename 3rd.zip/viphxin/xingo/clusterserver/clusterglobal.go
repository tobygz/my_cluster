package clusterserver

var GlobalMaster *Master
var GlobalClusterServer *ClusterServer
